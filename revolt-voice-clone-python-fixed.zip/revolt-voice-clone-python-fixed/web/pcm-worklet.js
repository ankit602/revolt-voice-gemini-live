class PCMWorklet extends AudioWorkletProcessor {
  static get parameterDescriptors(){ return []; }
  constructor(){ super(); this.buffer=[]; this.down = 48000/16000; this.acc=0; }

  process(inputs){
    const input = inputs[0];
    if (!input || input.length === 0) return true;
    const ch = input[0]; // mono
    for (let i=0;i<ch.length;i++){
      this.acc += 1;
      // simple decimation 48k -> 16k (works fine for live voice)
      if (this.acc >= this.down){ this.acc -= this.down; this.buffer.push(ch[i]); }
    }
    if (this.buffer.length >= 1600){ // ~100ms at 16kHz
      const pcm16 = new Int16Array(this.buffer.length);
      for (let i=0;i<this.buffer.length;i++){
        const s = Math.max(-1, Math.min(1, this.buffer[i]));
        pcm16[i] = s < 0 ? s * 0x8000 : s * 0x7FFF;
      }
      this.port.postMessage(pcm16.buffer, [pcm16.buffer]);
      this.buffer.length = 0;
    }
    return true;
  }
}
registerProcessor('pcm-worklet', PCMWorklet);
