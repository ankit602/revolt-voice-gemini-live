// web/app.js — final client
// - Streams mic as PCM 16 kHz (AudioWorklet)
// - Plays model audio smoothly via WebAudio (queues PCM → AudioBuffer)
// - Wraps non-PCM formats to <audio> as fallback
// - Buffers text deltas into one flowing line

const ws = new WebSocket(`ws://${location.hostname}:8000/ws`);

const logEl       = document.getElementById('log');
const startBtn    = document.getElementById('startBtn');
const stopBtn     = document.getElementById('stopBtn');
const sendBtn     = document.getElementById('sendText');
const inputEl     = document.getElementById('textInput');
const interruptBtn= document.getElementById('interruptBtn');
const audioEl     = document.getElementById('player'); // fallback only

let inCtx, micNode, workletNode, frames = 0;

// ---------------- Logging helpers ----------------
function log(line) {
  logEl.textContent += line + "\n";
  logEl.scrollTop = logEl.scrollHeight;
}
function setLastLogLine(s) {
  const lines = logEl.textContent.split("\n");
  const idx = Math.max(0, lines.length - 2);
  lines[idx] = s;
  logEl.textContent = lines.join("\n");
  logEl.scrollTop = logEl.scrollHeight;
}
function bytesToB64(u8) {
  let s = "";
  for (let i = 0; i < u8.length; i++) s += String.fromCharCode(u8[i]);
  return btoa(s);
}

// ---------------- Outgoing (mic) setup ----------------
async function startMic(){
  inCtx = new (window.AudioContext || window.webkitAudioContext)({ sampleRate: 48000 });
  await inCtx.audioWorklet.addModule("pcm-worklet.js");

  const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
  micNode = inCtx.createMediaStreamSource(stream);
  workletNode = new AudioWorkletNode(inCtx, "pcm-worklet");

  workletNode.port.onmessage = (e) => {
    if (ws.readyState !== WebSocket.OPEN) return;
    const buf = new Uint8Array(e.data); // Int16 PCM @16k
    ws.send(JSON.stringify({
      type: "audio",
      data: bytesToB64(buf),
      mime: "audio/pcm;rate=16000"
    }));
    frames++; if (frames % 20 === 0) console.log("mic frames sent:", frames);
  };

  micNode.connect(workletNode);
  // Do NOT connect to destination to avoid sidetone/echo:
  // workletNode.connect(inCtx.destination);

  frames = 0;
  startBtn.disabled = true;
  stopBtn.disabled  = false;
  log("🎙️ Mic started (PCM 16kHz)");
}

function stopMic(){
  try { micNode?.disconnect(); workletNode?.disconnect(); inCtx?.close(); } catch {}
  if (ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify({ type: "end_turn" })); // finalize turn so model replies
  }
  frames = 0;
  startBtn.disabled = false;
  stopBtn.disabled  = true;
  log("⏹️ Mic stopped");
}

// ---------------- Incoming (model audio) player ----------------
// Smooth, low-latency playback by enqueueing PCM chunks into WebAudio.
let outCtx, outGain, playHead = 0;

function ensureOutCtx() {
  if (outCtx) return;
  outCtx = new (window.AudioContext || window.webkitAudioContext)();
  outGain = outCtx.createGain();
  outGain.gain.value = 1.0; // tweak if output is too quiet/loud
  outGain.connect(outCtx.destination);
}

function parseSampleRate(mime, fallback = 24000) {
  if (!mime) return fallback;
  const m = /rate\s*=\s*(\d+)/i.exec(mime);
  return m ? parseInt(m[1], 10) : fallback;
}

function enqueuePCM(int16Bytes, sampleRate) {
  ensureOutCtx();
  // Convert Int16 -> Float32 [-1,1]
  const N = int16Bytes.length / 2;
  const f32 = new Float32Array(N);
  for (let i = 0, j = 0; i < N; i++, j += 2) {
    const val = (int16Bytes[j] | (int16Bytes[j+1] << 8));
    const s = val < 0x8000 ? val : val - 0x10000; // int16
    f32[i] = s / 0x8000;
  }

  const buffer = outCtx.createBuffer(1, N, sampleRate);
  buffer.copyToChannel(f32, 0, 0);

  const src = outCtx.createBufferSource();
  src.buffer = buffer;
  src.connect(outGain);

  const now = outCtx.currentTime;
  if (!playHead || playHead < now) playHead = now + 0.02; // small lead-in
  src.start(playHead);
  playHead += buffer.duration;
}

// ---------------- Text streaming (single flowing line) ----------------
let streamingText = false;
let textBuffer = "";

// ---------------- WebSocket handlers ----------------
ws.onopen  = () => log("connected");
ws.onclose = () => log("websocket closed");
ws.onerror = () => log("websocket error");

ws.onmessage = async (evt) => {
  const m = JSON.parse(evt.data);

  if (m.type === "text") {
    textBuffer += m.data || "";
    if (!streamingText) { log("Rev: "); streamingText = true; }
    setLastLogLine("Rev: " + textBuffer);
  }

  if (m.type === "done") {
    streamingText = false;
    textBuffer = "";
  }

  if (m.type === "audio") {
    const raw = Uint8Array.from(atob(m.data), c => c.charCodeAt(0));
    const mime = m.mime || "audio/pcm;rate=24000";

    if ((mime || "").startsWith("audio/pcm")) {
      // Queue PCM frames via WebAudio for smooth playback
      enqueuePCM(raw, parseSampleRate(mime, 24000));
    } else {
      // If server ever sends a container (wav/ogg/mp3), fall back to <audio>
      const blob = new Blob([raw], { type: mime });
      const url = URL.createObjectURL(blob);
      audioEl.src = url;
      try { await audioEl.play(); } catch {}
    }
  }

  if (m.type === "interrupted") {
    // Stop any queued speech if you're also using speechSynthesis
    try { speechSynthesis.cancel(); } catch {}
  }

  if (m.type === "error") {
    log("Server error: " + m.data);
  }
};

// ---------------- UI bindings ----------------
startBtn.onclick = startMic;
stopBtn.onclick  = stopMic;

interruptBtn.onclick = () => {
  if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify({ type: "interrupt" }));
  log("⏹️ Interrupted");
};

sendBtn.onclick = () => {
  const t = (inputEl.value || "").trim();
  if (!t) return;
  if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify({ type: "text", data: t }));
  log(`You: ${t}`);
  inputEl.value = "";
};
