import 'dotenv/config';
import express from 'express';
import http from 'http';
import path from 'path';
import { fileURLToPath } from 'url';
import { WebSocketServer, WebSocket as WS } from 'ws';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT  = process.env.PORT || 8000;
const API_KEY = process.env.GOOGLE_API_KEY;
const MODEL = process.env.GEMINI_MODEL || 'gemini-2.5-flash-preview-native-audio-dialog';

if (!API_KEY) {
  console.error('GOOGLE_API_KEY missing. Create server/.env and set GOOGLE_API_KEY.');
  process.exit(1);
}

const SYSTEM_PROMPT =
  "You are Rev, the Revolt Motors assistant. Only answer questions related to Revolt Motors motorcycles, charging, service, pricing, availability, test rides, specifications, financing, and official contact details. If asked unrelated questions, briefly steer the user back to Revolt topics.";

const app = express();
app.use('/web', express.static(path.resolve(__dirname, '..', 'web')));
app.get('/', (_req, res) => res.redirect('/web/'));

const server = http.createServer(app);
const wss = new WebSocketServer({ server, path: '/ws' });

wss.on('connection', (browserWS) => {
  const upstreamUrl =
    `wss://generativelanguage.googleapis.com/ws/` +
    `google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=${API_KEY}`;

  const upstream = new WS(upstreamUrl);

  let setupComplete = false;

  // Silence → finalize parameters
  const FINALIZE_AFTER_MS = 700;
  let finalizeTimer = null;
  let audioFrames = 0;

  const kickFinalizeTimer = () => {
    if (finalizeTimer) clearTimeout(finalizeTimer);
    finalizeTimer = setTimeout(() => {
      try {
        upstream.send(JSON.stringify({ clientContent: { turnComplete: true } }));
        console.log('[TURN] auto turnComplete (idle)');
      } catch {}
    }, FINALIZE_AFTER_MS);
  };

  const forceFinalize = () => {
    if (finalizeTimer) clearTimeout(finalizeTimer);
    try {
      upstream.send(JSON.stringify({ clientContent: { turnComplete: true } }));
      console.log('[TURN] forced turnComplete');
    } catch {}
  };

  // ---------- Upstream (Gemini Live) ----------
  upstream.on('open', () => {
    console.log('[LIVE] upstream open');
    const setup = {
      setup: {
        model: `models/${MODEL}`,
        generationConfig: { responseModalities: ['AUDIO'] },
        // ✅ MUST be a Content object, not a plain string
        systemInstruction: {
          role: 'system',
          parts: [{ text: SYSTEM_PROMPT }]
        },
        // helpful while debugging
        inputAudioTranscription: {},
        outputAudioTranscription: {}
      }
    };
    upstream.send(JSON.stringify(setup));
    console.log('[LIVE] sent setup');
  });

  upstream.on('message', (data) => {
    let msg;
    try { msg = JSON.parse(data.toString()); } catch { return; }

    if (msg.setupComplete) {
      setupComplete = true;
      console.log('[LIVE] setupComplete');
      return;
    }
    if (msg.error) {
      console.error('[LIVE] error:', msg.error);
      try { browserWS.send(JSON.stringify({ type: 'error', data: String(msg.error) })); } catch {}
      return;
    }

    const sc = msg.serverContent;
    if (sc) {
      if (sc.interrupted) {
        console.log('[LIVE] interrupted');
        try { browserWS.send(JSON.stringify({ type: 'interrupted' })); } catch {}
      }
      if (sc.outputTranscription?.text) {
        console.log('[LIVE] outputTranscript:', sc.outputTranscription.text);
        try { browserWS.send(JSON.stringify({ type: 'text', data: sc.outputTranscription.text })); } catch {}
      }
      const parts = sc.modelTurn?.parts || [];
      for (const p of parts) {
        if (typeof p.text === 'string' && p.text.length) {
          console.log('[LIVE] text:', p.text);
          try { browserWS.send(JSON.stringify({ type: 'text', data: p.text })); } catch {}
        }
        const inline = p.inlineData || p.inline_data || p.audio;
        const mime = inline?.mimeType || inline?.mime_type || '';
        if (inline?.data && mime.startsWith('audio/')) {
          try { browserWS.send(JSON.stringify({ type: 'audio', data: inline.data, mime })); } catch {}
        }
      }
      if (sc.turnComplete) {
        console.log('[LIVE] turnComplete');
        try { browserWS.send(JSON.stringify({ type: 'done' })); } catch {}
      }
      return;
    }

    if (msg.textDelta) {
      console.log('[LIVE] textDelta:', msg.textDelta);
      try { browserWS.send(JSON.stringify({ type: 'text', data: msg.textDelta })); } catch {}
    }
  });

  upstream.on('close', (code, reason) => {
    console.log('[LIVE] upstream closed', code, reason?.toString());
    try { browserWS.close(); } catch {}
  });
  upstream.on('error', (err) => {
    console.error('[LIVE] upstream error:', err.message);
    try { browserWS.send(JSON.stringify({ type: 'error', data: 'Upstream error' })); } catch {}
  });

  // ---------- Browser → Upstream ----------
  browserWS.on('message', (raw) => {
    let m; try { m = JSON.parse(raw.toString()); } catch { return; }

    if (m.type === 'audio') {
      if (m.mime && !m.mime.startsWith('audio/pcm')) {
        console.warn('[WS] non-PCM mime from browser:', m.mime);
      }
      upstream.send(JSON.stringify({
        realtimeInput: { audio: { data: m.data, mimeType: m.mime || 'audio/pcm;rate=16000' } }
      }));
      audioFrames++;
      if (audioFrames % 20 === 0) console.log(`[WS] audio frames sent: ${audioFrames}`);
      kickFinalizeTimer(); // restart silence debounce each chunk
    } else if (m.type === 'text') {
      upstream.send(JSON.stringify({
        clientContent: {
          turns: [{ role: 'user', parts: [{ text: m.data }]}],
          turnComplete: true
        }
      }));
      console.log('[WS] text turnComplete');
    } else if (m.type === 'interrupt') {
      upstream.send(JSON.stringify({
        clientContent: { turns: [{ role: 'user', parts: [{ text: '' }]}], turnComplete: true }
      }));
      console.log('[WS] interrupt');
    } else if (m.type === 'end_turn') {
      forceFinalize();
    }
  });

  browserWS.on('close', () => {
    if (finalizeTimer) clearTimeout(finalizeTimer);
    try { upstream.close(); } catch {}
  });
});

server.listen(PORT, () => {
  console.log(`Server running at http://127.0.0.1:${PORT}  (UI at /web)`);
});
